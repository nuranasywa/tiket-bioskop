<?php
namespace DummyNamespace;
use Illuminate\Database\Eloquent\Relations\Pivot;
class DummyClass extends Pivot
{
    //
}