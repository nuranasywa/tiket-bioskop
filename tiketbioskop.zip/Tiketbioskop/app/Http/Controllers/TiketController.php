<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Models\Tiket;

class TiketController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function index()
    {
        $tiket = tiket::all();
        return response()->json($tiket);
    }

    public function create(Request $request)
    {
        $this->validate($request, [
            "kode_tiket" => "required|unique:tiket",
            "judul_film" => "required",
            "nama_pemesan" => "required",
            "tgl_nonton" => "required",
            "row_seat" => "required",
            "no_seat" => "required",
            "jam_mulai" => "required",
            "studio" => "required",
            "harga" => "required"
        ]);

        $data = $request->all();
        $tiket = tiket::create($data);
        return response()->json($tiket);
    }

    public function show($id)
    {
        $tiket = tiket::find($id);
        if(!$tiket){
            return response()->json(['message' => 'Data not found, Please check the ID!'], 404);
        }
        return response()->json($tiket);
    }

    public function update(Request $request, $id)
    {
        $tiket = tiket::find($id);
        if(!$tiket){
            return response()->json(['message' => 'Data not found, Please check the ID!'], 404);
        }

        $this->validate($request, [
            "kode_tiket" => "required",
            "judul_film" => "required",
            "nama_pemesan" => "required",
            "tgl_nonton" => "required",
            "row_seat" => "required",
            "no_seat" => "required",
            "jam_mulai" => "required",
            "studio" => "required",
            "harga" => "required",
        ]);

        $data = $request->all();
        $tiket->fill($data);
        $tiket->save();
        return response()->json($tiket);
    }

    public function destroy($id)
    {
        $tiket = tiket::find($id);
        
        if (!$tiket) {
            return response()->json(['message' => 'Data not found , Please check the ID'], 404);
        }

        $tiket->delete();

        return response()->json(['message' => 'Data has been DELETED'], 200);
    }
}
?>