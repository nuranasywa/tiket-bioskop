<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Tiket extends Model
{
    protected $table = 'tiket';
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'kode_tiket','judul_film', 'nama_pemesan','tgl_nonton','row_seat','no_seat','jam_mulai','studio','harga'
    ];

} 