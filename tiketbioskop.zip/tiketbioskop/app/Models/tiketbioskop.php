<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class tiketbioskop extends Model
{
    protected $fillable = array('kode_tiket','judul_film','nama_pemesanan','tgl_nonton','row_set','no_seat','jam_mulai','studio','harga');
}
