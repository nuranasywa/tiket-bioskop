<?php

namespace App\Http\Controllers;

use App\Models\tiketbioskop;
use Illuminate\Http\Request;

class tiketbioskopController extends Controller
{
    public function __contruct(\App\Models\tiketbioskop $tiketbioskop){
        $this->tiketbioskop =$tiketbioskop;
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $data = tiketbioskop::All();
        return response($data);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $data = new tiketbioskop();
        $data-> kode_tiket = $request->input('kode_tiket');
        $data-> judul_film = $request->input('judul_film');
        $data-> nama_pemesanan = $request->input('nama_pemesanan');
        $data-> tgl_nonton = $request->input('tgl_nonton');
        $data-> row_set = $request->input('row_set');
        $data-> no_seat = $request->input('no_seat');
        $data-> jam_mulai = $request->input('jam_mulai');
        $data-> studio = $request->input('studio');
        $data-> harga = $request->input('harga');
        $data->save();
        return response($data);
        

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $data= tiketbioskop::where('id',$id)->get();
        return response($data);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $data= tiketbioskop::where('id',$id)->first();
        $data-> kode_tiket = $request->input('kode_tiket');
        $data-> judul_film = $request->input('judul_film');
        $data-> nama_pemesanan = $request->input('nama_pemesanan');
        $data-> tgl_nonton = $request->input('tgl_nonton');
        $data-> row_set = $request->input('row_set');
        $data-> no_seat = $request->input('no_seat');
        $data-> jam_mulai = $request->input('jam_mulai');
        $data-> studio = $request->input('studio');
        $data-> harga = $request->input('harga');
        $data->save();
        return response($data);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $data=tiketbioskop::where('id',$id)->first();
        if (!$data) {
            return response()->json(['message' => 'Data not found , Please check the ID'], 404);
        }

        $data->delete();

        return response()->json(['message' => 'Data has been DELETED'], 200);
    }
}
